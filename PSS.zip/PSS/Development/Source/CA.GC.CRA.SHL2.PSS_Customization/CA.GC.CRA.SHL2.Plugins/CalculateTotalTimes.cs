using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System.Collections.Generic;

namespace CA.GC.CRA.SHL2.Plugins
{
    /// <summary>
    /// CalculateTotalTimes Plugin.
    /// </summary>    
    public class CalculateTotalTimes: PluginBase
    {
        private string startDateField = null;
        private string endDateField = null;

        /// <summary>
        /// Initializes a new instance of the <see cref="CalculateTotalTimes"/> class.
        /// </summary>
        /// <param name="unsecure">Contains public (unsecured) configuration information.</param>
        /// <param name="secure">Contains non-public (secured) configuration information. 
        /// When using Microsoft Dynamics 365 for Outlook with Offline Access, 
        /// the secure string is not passed to a plug-in that executes while the client is offline.</param>
        public CalculateTotalTimes(string unsecure, string secure)
            : base(typeof(CalculateTotalTimes))
        {
            if (string.IsNullOrWhiteSpace(unsecure))
                throw new InvalidPluginExecutionException("Missing plugin configuration for Start Date and End Date fields.\r\n");

            var dateFields = unsecure.Split(',');
            if(dateFields.Length <= 1)
                throw new InvalidPluginExecutionException("Incorrect plugin configuration for Start Date and End Date fields.\r\n");

            startDateField = dateFields[0];
            endDateField = dateFields[1];
        }


        /// <summary>
        /// Main entry point for he business logic that the plug-in is to execute.
        /// </summary>
        /// <param name="localContext">The <see cref="LocalPluginContext"/> which contains the
        /// <see cref="IPluginExecutionContext"/>,
        /// <see cref="IOrganizationService"/>
        /// and <see cref="ITracingService"/>
        /// </param>
        /// <remarks>
        /// For improved performance, Microsoft Dynamics 365 caches plug-in instances.
        /// The plug-in's Execute method should be written to be stateless as the constructor
        /// is not called for every invocation of the plug-in. Also, multiple system threads
        /// could execute the plug-in at the same time. All per invocation state information
        /// is stored in the context. This means that you should not use global variables in plug-ins.
        /// </remarks>
        protected override void ExecuteCrmPlugin(LocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("localContext");
            }

            IPluginExecutionContext context = localContext.PluginExecutionContext;

            Entity preImageEntity = (context.PreEntityImages != null && context.PreEntityImages.Contains(this.preImageAlias)) ? context.PreEntityImages[this.preImageAlias] : null;
            Entity postImageEntity = (context.PostEntityImages != null && context.PostEntityImages.Contains(this.postImageAlias)) ? context.PostEntityImages[this.postImageAlias] : null; 
            if(preImageEntity == null && postImageEntity == null)
            {
                throw new InvalidPluginExecutionException("Missing Image.\r\n");
            }

            var imageEntity = preImageEntity != null ? preImageEntity : postImageEntity;
            var screeningCase = imageEntity.GetAttributeValue<EntityReference>("cra_security_screening_case");
            if(screeningCase != null)
                UpdateTotalTimes(localContext, screeningCase, imageEntity);
        }

        private void UpdateTotalTimes(LocalPluginContext localContext, EntityReference screeningCase, Entity record)
        {
            int totalMonth = 0;
            int totalMonthInCanada = 0;
            int totalMonthAbroad = 0;
            decimal totalYear = 0.0m;
            decimal totalYearInCanada = 0.0m;
            decimal totalYearAbroad = 0.0m;

            int gapMonths = 0;
            bool overlap = false;
            DateTime previousStart = DateTime.MaxValue;
            DateTime previousEnd = DateTime.MaxValue;
            DateTime currentStart = DateTime.MaxValue;
            DateTime currentEnd = DateTime.MaxValue;

            SortedList<DateTime, int> reportedMonths = new SortedList<DateTime, int>();
            SortedList<DateTime, int> reportedMonthInCanada = new SortedList<DateTime, int>();
            SortedList<DateTime, int> reportedMonthAbroad = new SortedList<DateTime, int>();
            var queryChildRecords = new QueryExpression(record.LogicalName);
            queryChildRecords.ColumnSet.AddColumns(startDateField, endDateField, "cra_country");
            queryChildRecords.Criteria.AddCondition("cra_security_screening_case", ConditionOperator.Equal, screeningCase.Id);
            queryChildRecords.AddOrder(startDateField, OrderType.Ascending);
            queryChildRecords.AddOrder(endDateField, OrderType.Ascending);
            var childRecords = localContext.OrganizationService.RetrieveMultiple(queryChildRecords);
            foreach (var childRecod in childRecords.Entities)
            {
                var abroad = 0;
                var country = childRecod.GetAttributeValue<EntityReference>("cra_country");
                if (country != null && country.Id == CANADA)
                {
                    abroad = 0;
                }
                else if (country != null)
                    abroad = 1;

                currentStart = childRecod.GetAttributeValue<DateTime>(startDateField);
                currentEnd = childRecod.GetAttributeValue<DateTime>(endDateField);

                currentStart = new DateTime(currentStart.Year, currentStart.Month, 1);
                currentEnd = new DateTime(currentEnd.Year, currentEnd.Month, 1);

                var month = currentStart;
                while (month <= currentEnd)
                {
                    if (reportedMonths.ContainsKey(month))
                    {
                        if(month != currentStart) overlap = true;
                    }
                    else
                    {
                        reportedMonths.Add(month, abroad);
                    }

                    if(abroad == 0)
                    {
                        if (!reportedMonthInCanada.ContainsKey(month))
                            reportedMonthInCanada.Add(month, abroad);
                    }
                    else
                    {
                        if (!reportedMonthAbroad.ContainsKey(month))
                            reportedMonthAbroad.Add(month, abroad);
                    }

                    month = month.AddMonths(1);
                }
            }

            totalMonth = reportedMonths.Count;
            totalMonthInCanada = reportedMonthInCanada.Count;
            totalMonthAbroad = reportedMonthAbroad.Count;
  
            totalYear = (decimal)totalMonth / MONTHS_IN_YEAR;
            totalYearInCanada = (decimal)totalMonthInCanada / MONTHS_IN_YEAR;
            totalYearAbroad = (decimal)totalMonthAbroad / MONTHS_IN_YEAR;

            Entity updateCase = new Entity(screeningCase.LogicalName, screeningCase.Id);
            updateCase[string.Format("{0}_total_months", record.LogicalName)] = totalMonth;
            updateCase[string.Format("{0}_total_years", record.LogicalName)] = totalYear;
            updateCase[string.Format("{0}_months_in_canada", record.LogicalName)] = totalMonthInCanada;
            updateCase[string.Format("{0}_years_in_canada", record.LogicalName)] = totalYearInCanada;
            updateCase[string.Format("{0}_months_abroad", record.LogicalName)] = totalMonthAbroad;
            updateCase[string.Format("{0}_years_abroad", record.LogicalName)] = totalYearAbroad;
            updateCase[string.Format("{0}_gap", record.LogicalName)] = gapMonths;
            updateCase[string.Format("{0}_overlap", record.LogicalName)] = overlap;

            localContext.OrganizationService.Update(updateCase);
        }

        private int GetMonthDifference(DateTime startDate, DateTime endDate)
        {
            return MONTHS_IN_YEAR * (endDate.Year - startDate.Year) + (endDate.Month - startDate.Month); 
        }
    }
}
