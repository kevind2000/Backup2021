using System;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace CA.GC.CRA.SHL2.Plugins
{
    /// <summary>
    /// CalcaulateLatestConsent Plugin.
    /// </summary>    
    public class CalcaulateLatestConsent: PluginBase
    {
     
        /// <summary>
        /// Initializes a new instance of the <see cref="CalcaulateLatestConsent"/> class.
        /// </summary>
        /// <param name="unsecure">Contains public (unsecured) configuration information.</param>
        /// <param name="secure">Contains non-public (secured) configuration information. 
        /// When using Microsoft Dynamics 365 for Outlook with Offline Access, 
        /// the secure string is not passed to a plug-in that executes while the client is offline.</param>
        public CalcaulateLatestConsent(string unsecure, string secure)
            : base(typeof(CalcaulateLatestConsent))
        {
           
        }

        /// <summary>
        /// Main entry point for he business logic that the plug-in is to execute.
        /// </summary>
        /// <param name="localContext">The <see cref="LocalPluginContext"/> which contains the
        /// <see cref="IPluginExecutionContext"/>,
        /// <see cref="IOrganizationService"/>
        /// and <see cref="ITracingService"/>
        /// </param>
        /// <remarks>
        /// For improved performance, Microsoft Dynamics 365 caches plug-in instances.
        /// The plug-in's Execute method should be written to be stateless as the constructor
        /// is not called for every invocation of the plug-in. Also, multiple system threads
        /// could execute the plug-in at the same time. All per invocation state information
        /// is stored in the context. This means that you should not use global variables in plug-ins.
        /// </remarks>
        protected override void ExecuteCrmPlugin(LocalPluginContext localContext)
        {
            if (localContext == null)
            {
                throw new InvalidPluginExecutionException("localContext");
            }

            IPluginExecutionContext context = localContext.PluginExecutionContext;

            Entity preImageEntity = (context.PreEntityImages != null && context.PreEntityImages.Contains(this.preImageAlias)) ? context.PreEntityImages[this.preImageAlias] : null;
            Entity postImageEntity = (context.PostEntityImages != null && context.PostEntityImages.Contains(this.postImageAlias)) ? context.PostEntityImages[this.postImageAlias] : null; 
            if(preImageEntity == null && postImageEntity == null)
            {
                throw new InvalidPluginExecutionException("Missing Image.\r\n");
            }

            if(preImageEntity != null) // Update or Delete
            {
                UpdateLatestConsent(localContext, preImageEntity);
            }

            if (postImageEntity != null) //Update or Create
            {
                UpdateLatestConsent(localContext, postImageEntity);
            }
        }

        private void UpdateLatestConsent(LocalPluginContext localContext, Entity consent)
        {
            var profile = consent.GetAttributeValue<EntityReference>("cra_security_profile");
            var verification = consent.GetAttributeValue<OptionSetValue>("cra_verification");

            // Get current latest consent for the verification
            var queryCurrent = new QueryExpression(consent.LogicalName);
            queryCurrent.ColumnSet.AddColumns("cra_latest_consent");
            queryCurrent.Criteria.AddCondition("cra_security_profile", ConditionOperator.Equal, profile.Id);
            queryCurrent.Criteria.AddCondition("cra_verification", ConditionOperator.Equal, verification.Value);
            queryCurrent.Criteria.AddCondition("cra_consent_given_status", ConditionOperator.Equal, 171100001); // Yes
            queryCurrent.Criteria.AddCondition("cra_latest_consent", ConditionOperator.Equal, 171100000); // Yes
            var currentRecords = localContext.OrganizationService.RetrieveMultiple(queryCurrent);

            // Get the latest consent 
            var queryLatest = new QueryExpression(consent.LogicalName);
            queryLatest.ColumnSet.AddColumns("cra_latest_consent");
            queryLatest.Criteria.AddCondition("cra_security_profile", ConditionOperator.Equal, profile.Id);
            queryLatest.Criteria.AddCondition("cra_verification", ConditionOperator.Equal, verification.Value);
            queryLatest.Criteria.AddCondition("cra_consent_given_status", ConditionOperator.Equal, 171100001); // Yes
            queryLatest.AddOrder("cra_account_consent_given_date", OrderType.Descending);
            queryLatest.TopCount = 1;
            var latestRecords = localContext.OrganizationService.RetrieveMultiple(queryLatest);
            var latestRecord = latestRecords.Entities.Count == 0 ? null : latestRecords.Entities[0];

            foreach(var currentRecord in currentRecords.Entities)
            {
                if (latestRecord != null && currentRecord.Id != latestRecord.Id)
                {
                    currentRecord["cra_latest_consent"] = null;
                    localContext.OrganizationService.Update(currentRecord);
                }
            }

            if (latestRecord != null && latestRecord.Contains("cra_latest_consent") == false)
            {
                latestRecord["cra_latest_consent"] = new OptionSetValue(171100000);
                localContext.OrganizationService.Update(latestRecord);
            }
        }
    }
}
