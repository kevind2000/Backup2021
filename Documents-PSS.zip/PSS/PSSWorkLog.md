# PSS Work Log
## Project Onboard ##

**2021-01-26**: Working Laptop Set up; NewHire Welcome Package; GCcase - Development and Support Team <- Appeals and Case Management (ACM) <- Debt Management, Regulatory Affairs, and Appeals Directorate (DMRAAAD)

**2021-01-27**: GCcase Development Procedures; GCcase Development Process Diagram; GCcase Peer Review User Guide;  

**2021-01-28**: PSS IT Team Discussion; iceScrum - PSS; iceScrum User Guide; PSS High Level Business Requirements

**2020-01-29**: PSS Project Plan; IT Team meeting; Development and Prototyping Directives; Project Charter; Current Workflow Diagrams

## PSS Release 1 Sprint 2 ##
	
- Get familiar with lab environment and PSS POC solution; 
- Set up development machine and environment;
- Clean up and changes in PSS POC solution;
- Update and clean up technical documents;
- Create new solution for sprint development;
- Create new document for solution deployment;
  
### Week 1

**2020-02-01**: Sprint 1 Review and Retrospective; Current Workflow Diagrams; Go through Sprint 2 user stories; Discussion with Joel; Preparation for Sprint 2 Planning;

**2020-02-02**: Sprint 2 Planning meeting; Sprint 2 User Stories; 

**2020-02-03**: PSS POC; PSS Demo with Matt; Sprint 2 User Stories Effort Estimate meeting; Explore PSS POC solutions in DEV environment. 

### Week 2
**2020-02-09**: user story #40, $43