var currentDateField = "cra_current_date";

var employmentStatus = "cra_employment_status";

var currentStatus = "cra_current_status";
var from = "cra_status_from";
var to = "cra_status_to";
var employer = "cra_employer_or_institution";
var jobTitle = "cra_job_title";
var fieldStudy = "cra_field_of_study";
var classification = "cra_classification";
var description = "cra_description";
var email = "cra_work_or_school_email";
var phone = "cra_work_telephone_number";
var foreignWork = "cra_foreign_work";

var supervisorName = "cra_supervisor_name";
var supervisorTitle = "cra_supervisor_title";
var supervisorEmail = "cra_supervisor_email";
var supervisorPhone = "cra_supervisor_telephone";
var alternateRequired = "cra_alternate_required";
var alternateReason = "cra_alternate_reason";

var addressStreetNumber = "cra_street_number";
var addressStreetName = "cra_street_name";
var addressCity = "cra_city_or_town";
var addressCountry = "cra_country";
var addressProvince = "cra_province_or_state";
var addressOther = "cra_provinceother";

var alternateName = "cra_alternate_name";
var alternateTitle = "cra_alternate_title";
var alternateEmail = "cra_alternate_email";
var alternatePhone = "cra_alternate_telephone";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getAttribute(currentDateField).setValue(new Date());
    displayByEmploymentStatus(executionContext);
}

function onEmploymentStatusChange(executionContext)
{
    var formContext = executionContext.getFormContext();

    formContext.getAttribute(currentStatus).setValue(null);
    formContext.getAttribute(from).setValue(null);
    formContext.getAttribute(to).setValue(null);
    formContext.getAttribute(employer).setValue(null);
    formContext.getAttribute(jobTitle).setValue(null);
    formContext.getAttribute(fieldStudy).setValue(null);
    formContext.getAttribute(classification).setValue(null);
    formContext.getAttribute(description).setValue(null);
    formContext.getAttribute(email).setValue(null);
    formContext.getAttribute(phone).setValue(null);     
    formContext.getAttribute(foreignWork).setValue(null);

    formContext.getAttribute(supervisorName).setValue(null);
    formContext.getAttribute(supervisorEmail).setValue(null);
    formContext.getAttribute(supervisorTitle).setValue(null);
    formContext.getAttribute(supervisorPhone).setValue(null);
    formContext.getAttribute(alternateRequired).setValue(null);
    formContext.getAttribute(alternateReason).setValue(null);
    formContext.getAttribute(addressStreetNumber).setValue(null);
    formContext.getAttribute(addressStreetName).setValue(null);
    formContext.getAttribute(addressCity).setValue(null);
    formContext.getAttribute(addressCountry).setValue(null);
    formContext.getAttribute(addressProvince).setValue(null);
    formContext.getAttribute(addressOther).setValue(null);        

    formContext.getAttribute(alternateName).setValue(null);
    formContext.getAttribute(alternateTitle).setValue(null);
    formContext.getAttribute(alternateEmail).setValue(null);
    formContext.getAttribute(alternatePhone).setValue(null);

    displayByEmploymentStatus(executionContext);
}

function displayByEmploymentStatus(executionContext)
{
    var formContext = executionContext.getFormContext();
    var employment = formContext.getAttribute(employmentStatus).getValue();

    if(employment == 171100000 ) // Employed
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secSupervisor").setVisible(true);                 
    }
    else
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secSupervisor").setVisible(false);
        formContext.getAttribute(supervisorName).setValue(null);
        formContext.getAttribute(supervisorEmail).setValue(null);
        formContext.getAttribute(supervisorTitle).setValue(null);
        formContext.getAttribute(supervisorPhone).setValue(null);
        formContext.getAttribute(alternateRequired).setValue(null);
        formContext.getAttribute(alternateReason).setValue(null);

        onAlternateRequiredChange(executionContext);
    }

    // Employed, Self-Employed, Student
    if(employment == 171100000 || employment ==  171100001 || employment ==  171100002) 
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secAddress").setVisible(true);   
        formContext.getControl(foreignWork).setVisible(true);              
    }
    else
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secAddress").setVisible(false);
        formContext.getAttribute(addressStreetNumber).setValue(null);
        formContext.getAttribute(addressStreetName).setValue(null);
        formContext.getAttribute(addressCity).setValue(null);
        formContext.getAttribute(addressCountry).setValue(null);
        formContext.getAttribute(addressProvince).setValue(null);
        formContext.getAttribute(addressOther).setValue(null);
        formContext.getControl(foreignWork).setVisible(false);              
        formContext.getAttribute(foreignWork).setValue(null);
    }
}

function onAlternateRequiredChange(executionContext)
{
    var formContext = executionContext.getFormContext();
    var alternate = formContext.getAttribute(alternateRequired).getValue();
    if(alternate == 171100000 ) // Yes
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secAlternate").setVisible(true);                 
    }
    else
    {
        formContext.ui.tabs.get("tabGeneral").sections.get("secAlternate").setVisible(false);
        formContext.getAttribute(alternateName).setValue(null);
        formContext.getAttribute(alternateTitle).setValue(null);
        formContext.getAttribute(alternateEmail).setValue(null);
        formContext.getAttribute(alternatePhone).setValue(null);
    }
}


