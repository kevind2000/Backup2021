function retrieveWebAPIData(entityName, select, filter, orderBy, expand) {
    //Will need to update this section when we go to v9
    //var globalContext = Xrm.Utility.getGlobalContext();
    //var serverUrl = globalContext.getClientUrl();
    //var ODATA_ENDPOINT = "/api/data/v9.0";

    var serverUrl = Xrm.Page.context.getClientUrl();
    var ODATA_ENDPOINT = "/api/data/v8.2";

    var odataUri = serverUrl + ODATA_ENDPOINT + "/" + entityName + "?";

    if (select) {
        odataUri += "$select=" + select;
    }

    if (filter) {
        odataUri += "&$filter=" + filter;
    }

    if (orderBy) {
        odataUri += "&$orderby=" + orderBy;
    }

    if (expand) {
        odataUri += "&$expand=" + expand;
    }

    var data;
    try {
        var req = new XMLHttpRequest();

        //alert(odataUri);
        req.open("GET", encodeURI(odataUri), false);

        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.send(null);

        data = JSON.parse(req.responseText, dateReviver);

        return data;
    }
    catch (ex) {
        alert("Error: retrieveWebAPIData - Data Set =" + odataSetName + "; filter = " + sFilter + "; select = " + sSelect + "; Error = " + ex.message);
    }
}

function retrieveWebAPIDataWithAnnotations(entityName, select, filter, orderBy) {
    //Will need to update this section when we go to v9
    //var globalContext = Xrm.Utility.getGlobalContext();
    //var serverUrl = globalContext.getClientUrl();
    var ODATA_ENDPOINT = "/api/data/v9.0";
    var serverUrl = Xrm.Page.context.getClientUrl();
    //var ODATA_ENDPOINT = "/api/data/v8.2";
    var odataUri = serverUrl + ODATA_ENDPOINT + "/" + entityName + "?";
    if (select) {
        odataUri += "$select=" + select;
    }
    if (filter) {
        odataUri += "&$filter=" + filter;
    }
    if (orderBy) {
        odataUri += "&$orderby=" + orderBy;
    }
    var data;
    try {
        var req = new XMLHttpRequest();
        req.open("GET", encodeURI(odataUri), false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send(null);
        data = JSON.parse(req.responseText, dateReviver);
        return data;
    }
    catch (ex) {
        alert("Error: retrieveWebAPIData - Data Set =" + entityName + "; filter = " + filter + "; select = " + select + "; Error = " + ex.message);
    }
}

function retrieveWebAPIDataFetchXml(entityName, fetchXML) {
    //Will need to update this section when we go to v9
    //var globalContext = Xrm.Utility.getGlobalContext();
    //var serverUrl = globalContext.getClientUrl();
    //var ODATA_ENDPOINT = "/api/data/v9.0";
    var serverUrl = Xrm.Page.context.getClientUrl();
    var ODATA_ENDPOINT = "/api/data/v8.2";
    var odataUri = serverUrl + ODATA_ENDPOINT + "/" + entityName + "?fetchXml=" + fetchXML;
    try {
        var req = new XMLHttpRequest();
        req.open("GET", encodeURI(odataUri), false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.send(null);
        data = JSON.parse(req.responseText, dateReviver);
        return data;
    }
    catch (ex) {
        alert("Error: retrieveWebAPIData - Data Set =" + entityName + "; fetchXml = " + fetchXML + "; Error = " + ex.message);
    }
}

function retrieveWebAPIDataFetchXmlWithAnnotations(entityName, fetchXML) {
    //Will need to update this section when we go to v9
    //var globalContext = Xrm.Utility.getGlobalContext();
    //var serverUrl = globalContext.getClientUrl();
    //var ODATA_ENDPOINT = "/api/data/v9.0";
    var serverUrl = Xrm.Page.context.getClientUrl();
    var ODATA_ENDPOINT = "/api/data/v8.2";
    var odataUri = serverUrl + ODATA_ENDPOINT + "/" + entityName + "?fetchXml=" + fetchXML;
    try {
        var req = new XMLHttpRequest();
        req.open("GET", encodeURI(odataUri), false);
        req.setRequestHeader("Accept", "application/json");
        req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
        req.setRequestHeader("Prefer", "odata.include-annotations=\"*\"");
        req.send(null);
        data = JSON.parse(req.responseText, dateReviver);
        return data;
    }
    catch (ex) {
        alert("Error: retrieveWebAPIData - Data Set =" + entityName + "; fetchXml = " + fetchXML + "; Error = " + ex.message);
    }
}

function dateReviver(key, value) {
    if (typeof value === 'string') {
        var a = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
        if (a) {
            return new Date(Date.UTC(+a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6]));
        }
    }
    return value;
};
