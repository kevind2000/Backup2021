using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
 
namespace RetrievemultiplePlugin
{
    public class RetrievemultiplePlugin : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
 
            IOrganizationServiceFactory factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
 
            IOrganizationService service = (IOrganizationService)factory.CreateOrganizationService(context.UserId);
            ITracingService tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            try
            {
                if (context.Mode == 0 &amp;&amp; context.Stage == 20 &amp;&amp; (context.MessageName.Equals("RetrieveMultiple")) &amp;&amp; context.Depth == 1)
                {
                    if (context.InputParameters.Contains("Query") &amp;&amp; context.PrimaryEntityName == "contact") //The primary entity on which the plugin has been registered
                    {                                                                                       //Or you can say the entity which is getting filteren on the view
                        if (context.InputParameters["Query"] is FetchExpression) // In UCI the query we get is in fetchExpression
                        {
                            var thisQuery = context.InputParameters["Query"];
                            var fetchExpressionQuery = thisQuery as FetchExpression;
                            if (fetchExpressionQuery != null)
                            {
                                XDocument fetchXmlDoc = XDocument.Parse(fetchExpressionQuery.Query); //We will parse the fetchExpression in fetchXml.
                                //The required entity element
 
                                fetchXmlDoc.Descendants("fetch").FirstOrDefault().Attribute("distinct").Value = "true"; //By default we will change
                                                                                                                           //the distinct attribute of fetch to true
 
                                if (fetchXmlDoc.Descendants("link-entity").FirstOrDefault() == null) //If link-entity not present in the attribute it will return.
                                    return;
                                var entityElement = fetchXmlDoc.Descendants("link-entity").FirstOrDefault();
                                var entityName = entityElement.Attributes("name").FirstOrDefault().Value;  //Gets the name of the link attribute, this link attribute
                                bool replace = false;                                                       //is the one which we added in the subgrid as related record.
 
                                string currentAPRId = string.Empty;
                                if (entityName == "new_areaofprimaryresponsibility")   //Checks the name of the linked entity.
                                {
                                    var filterElements = entityElement.Descendants("filter");
                                    //We will get all the filters in the fetch and find the condition which is matching to our related record so that
                                    //we get the Guid of our entity record  on which the form is.
 
                                    //Find any existing statecode conditions
                                    var prmAPRCondition = from c in filterElements.Descendants("condition")
                                                          where c.Attribute("attribute").Value.Equals("new_areaofprimaryresponsibilityid")      //prm_allocationid
                                                          select c;
                                    if (prmAPRCondition.Count() &gt; 0)
                                    {
                                        foreach (XElement el in prmAPRCondition)
                                            currentAPRId = (string)el.Attribute("value");  //Here we retrieve our required GUID to be furthere use in the code.
 
                                        prmAPRCondition.ToList().ForEach(x =&gt; x.Remove()); //Once we have our GUID, we will remove all the linked entity which is coming form the related part.
 
                                        //Now we will create our fetch in XMlDoc element.
 
                                        entityElement.ReplaceWith(new XElement("link-entity",
                                                    new XAttribute("name", "prm_contact_prm_location"),
                                                    new XAttribute("from", "contactid"), //not equal
                                                    new XAttribute("to", "contactid"), //not equal
                                                     new XAttribute("visible", "false"),
                                                    new XAttribute("intersect", "true"), //not equal
                                                    new XElement("link-entity",
                                                    new XAttribute("name", "prm_location"),
                                                    new XAttribute("from", "prm_locationid"), //not equal
                                                    new XAttribute("to", "prm_locationid"), //not equal
                                                    new XAttribute("alias", "ad"), //Inactive
                                                    new XElement("filter",
                                                    new XElement("condition",
                                                    new XAttribute("attribute", "prm_apr"),
                                                    new XAttribute("operator", "eq"), //not equal
                                                    new XAttribute("value", currentAPRId) //Inactive
                                                    )
                                                    )
                                                )
                                                )
                                                );
                                        replace = true;
                                    }
 
                                    if (replace)
                                    {
                                        fetchExpressionQuery.Query = fetchXmlDoc.ToString();
                                    }
                                }
                                else if (entityName == "prm_allocation")  //Used else because we are filtering on two entity.
                                {
                                    var filterElements = entityElement.Descendants("filter");
                                    //Find any existing statecode conditions
                                    var prmAPRCondition = from c in filterElements.Descendants("condition")
                                                          where c.Attribute("attribute").Value.Equals("prm_allocationid")      //prm_allocationid
                                                          select c;
                                    if (prmAPRCondition.Count() &gt; 0)
                                    {
                                        foreach (XElement el in prmAPRCondition)
                                            currentAPRId = (string)el.Attribute("value");
 
                                        prmAPRCondition.ToList().ForEach(x =&gt; x.Remove());
 
                                        Entity allocation = service.Retrieve("prm_allocation", new Guid(currentAPRId), new ColumnSet("prm_apr"));
                                        EntityReference aprReference = allocation.Contains("prm_apr") ? (EntityReference)allocation["prm_apr"] : null;
 
                                        if (aprReference == null)
                                            return;
 
                                        entityElement.ReplaceWith(new XElement("link-entity",
                                                    new XAttribute("name", "prm_contact_prm_location"),
                                                    new XAttribute("from", "contactid"), //not equal
                                                    new XAttribute("to", "contactid"), //not equal
                                                     new XAttribute("visible", "false"),
                                                    new XAttribute("intersect", "true"), //not equal
                                                    new XElement("link-entity",
                                                    new XAttribute("name", "prm_location"),
                                                    new XAttribute("from", "prm_locationid"), //not equal
                                                    new XAttribute("to", "prm_locationid"), //not equal
                                                    new XAttribute("alias", "ad"), //Inactive
                                                    new XElement("filter",
                                                    new XElement("condition",
                                                    new XAttribute("attribute", "prm_apr"),
                                                    new XAttribute("operator", "eq"), //not equal
                                                    new XAttribute("value", aprReference.Id))))), //Inactive
                                                    new XElement("link-entity",
                                                    new XAttribute("name", "prm_contact_prm_businessrole"),
                                                    new XAttribute("from", "contactid"), //not equal
                                                    new XAttribute("to", "contactid"), //not equal
                                                     new XAttribute("visible", "false"),
                                                    new XAttribute("intersect", "true"), //not equal
                                                    new XElement("link-entity",
                                                    new XAttribute("name", "prm_businessrole"),
                                                    new XAttribute("from", "prm_businessroleid"), //not equal
                                                    new XAttribute("to", "prm_businessroleid"), //not equal
                                                    new XAttribute("alias", "ae"),
                                                     new XElement("filter",
                                                    new XElement("condition",
                                                    new XAttribute("attribute", "prm_name"),
                                                    new XAttribute("operator", "like"), //not equal
                                                    new XAttribute("value", "%Specialist%") //Inactive
                                                    )
                                                    )
                                                )
                                                )
                                                );
                                        replace = true;
                                    }
 
                                    if (replace)
                                    {
                                        fetchExpressionQuery.Query = fetchXmlDoc.ToString();
                                    }
 
                                }
                            }
                        }
                    }
 
                }
            }
            catch (Exception ex)
            {
 
                throw new Exception(ex.Message + ex.InnerException);
            }
        }
    }
}