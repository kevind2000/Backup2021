// Web Resource: Consent Form Script

var currentDateField = "cra_current_date";
var caseField = "cra_security_screening_case";
var verificationField = "cra_verification";
var profileField = "cra_security_profile";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getAttribute(currentDateField).setValue(new Date());
}

function onCaseChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var screeningCase = formContext.getAttribute(caseField).getValue();
                
    if(screeningCase != null)
    {
        var caseId = getId(screeningCase[0].id);
        Xrm.WebApi.retrieveRecord("cra_securityscreenings", caseId, "?$select=_cra_security_profile_value").then(
            function success(result) {
                var profile = null;
                if(result._cra_security_profile_value != null)
                    profile = [{id:result._cra_security_profile_value, entityType: "cra_securityprofile", name: result["_cra_security_profile_value@OData.Community.Display.V1.FormattedValue"]}];
                formContext.getAttribute(profileField).setValue(profile);
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
    else 
    {
        formContext.getAttribute(profileField).setValue(null);
    }
}

function checkDuplicateVerificationRecord(executionContext) {
    var formContext = executionContext.getFormContext();
    var screeningCase = formContext.getAttribute(caseField).getValue();
    var verification = formContext.getAttribute(verificationField).getValue();
                
    var errId = "duplicateVerficationRecord";
    formContext.getControl(verificationField).clearNotification(errId);

    if(screeningCase != null && verification != null)
    {
        Xrm.WebApi.retrieveMultipleRecords("cra_consent", "?$select=cra_consentid&$filter=(cra_verification eq " + verification + " and _cra_security_screening_case_value eq " + getId(screeningCase[0].id) + ")&$top=10").then(
            function success(result) {
                var id = getId(formContext.data.entity.getId());
                var duplicate = false;

                for (var i = 0; i < result.entities.length; i++) {
                    if(result.entities[i].cra_consentid != id)
                    {
                        duplicate = true;
                        break;
                    }
                }   

                if(duplicate) 
                {
                    formContext.getControl(verificationField).setNotification("The Verfication record aleady exists.", errId);
                }
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
}