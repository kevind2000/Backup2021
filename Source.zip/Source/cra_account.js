// Web Resource: Account Form Script

var birthCountry = "cra_birth_country";
var birthProvince = "cra_birth_province";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    onCountryChange(executionContext);
}

function onCountryChange(executionContext) {
    // var formContext = executionContext.getFormContext();

    // var country = formContext.getAttribute(birthCountry).getValue();
    // if(country != null && country[0].id == "{F8E15F4C-C988-EB11-A82B-000D3A84E9E0}") //CANADA
    // {
    //     addPreSearchFilter(executionContext, "PROVINCE", birthProvince, birthCountry);
    //     setDefaultView(executionContext, birthProvince, "0DCDAE27-E188-EB11-A82B-000D3A84E9E0"); //Provinces/Territories View
    // } 
    // else if(country != null && country[0].id == "{6AE25F4C-C988-EB11-A82B-000D3A84E9E0}") // United States
    // {
    //     addPreSearchFilter(executionContext, "STATES", birthProvince, birthCountry);
    //     setDefaultView(executionContext, birthProvince, "AAAABCA0-E388-EB11-A82B-000D3A84E9E0"); //USA States View
    // }
}