// Web Resource: Fingerprint Form Script

var currentDateField = "cra_current_date";
var witnessField = "cra_witness";
var userIDField = "cra_userid";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getAttribute(currentDateField).setValue(new Date());
}

function onWitnessChange(executionContext)
{
    var formContext = executionContext.getFormContext();

    var witness = formContext.getAttribute(witnessField).getValue();
    if(witness == 171100000) // Myself
    {
        var userSettings = Xrm.Utility.getGlobalContext().userSettings;

        var userGUID = userSettings.userId;

        Xrm.WebApi.retrieveRecord("systemuser", getId(userGUID), "?$select=cra_usr_id").then(
            function success(result) {
                formContext.getAttribute(userIDField).setValue(result.cra_usr_id);
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
    else
    {
        formContext.getAttribute(userIDField).setValue('');
    }
}