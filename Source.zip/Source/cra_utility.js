var errDateNotPast = "date_not_past";
function checkPastDate(executionContext, dateField) {
    var formContext = executionContext.getFormContext();
    
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var dateValue = formContext.getAttribute(dateField).getValue();
    if(dateValue != null && dateValue < today)
    {
        formContext.getControl(dateField).setNotification("Date cannot be in the past.", errDateNotPast);
    }
    else
    {
        formContext.getControl(dateField).clearNotification(errDateNotPast);
    }
}

var currentDateField = "cra_current_date";
function setCurrentDate(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getAttribute(currentDateField).setValue(new Date());
}


function addSubgridEventListener(formContext, gridName, subgridEventListener){
    var gridControl = formContext.getControl(gridName);
    //ensure that the subgrid is ready…if not wait and call this function again
    if (gridControl == null)
    {
        setTimeout(function () { addSubgridEventListener(formContext, gridName); }, 500);
        return;
    }
    //bind the event listener when the subgrid is ready
    gridControl.addOnLoad(subgridEventListener);
}

function getId(id)
{
    return id.replace('{', '').replace('}', '').toLowerCase();
}