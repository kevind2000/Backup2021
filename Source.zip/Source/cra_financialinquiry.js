// Web Resource: Financial Inquiry Form Script

var financialInquiryField = "regardingobjectid";
var accountField = "cra_account";
var reasonField = "cra_reason";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getControl(financialInquiryField).setEntityTypes(['cra_securityscreenings']);

    onCaseChange(executionContext);
    // checkDuplicateInitialRecord(executionContext);
}

function onCaseChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var screeningCase = formContext.getAttribute(financialInquiryField).getValue();

    if(screeningCase != null)
    {
        var id = getId(formContext.data.entity.getId());
        if(id == "")
        {
            var caseId = getId(screeningCase[0].id);
            Xrm.WebApi.retrieveRecord("cra_securityscreenings", caseId, "?$expand=cra_account($select=accountid,cra_firstname,cra_lastname)").then(
                function success(result) {
                    var account = [{id:result.cra_account.accountid, entityType: "account", name: result.cra_account.cra_firstname + " " + result.cra_account.cra_lastname}];
                    formContext.getAttribute(accountField).setValue(account);
                },
                function (error) {
                    Xrm.Navigation.openAlertDialog({text: error.message});
                }
            );
        }
        
        // var id = getId(formContext.data.entity.getId());
        // if(id == "")
        // {
        //     Xrm.WebApi.retrieveMultipleRecords("cra_financial_inquiry", "?$select=activityid&$filter=(_regardingobjectid_value eq " + getId(screeningCase[0].id) + ")&$top=10").then(
        //         function success(result) {
        //             if(result.entities.length == 0) 
        //             {
        //                 formContext.getAttribute(reasonField).setValue(171100000); //Initial
        //                 formContext.getControl(reasonField).setDisabled(true);
        //             }
        //             else
        //             {
        //                 formContext.getControl(reasonField).setDisabled(false);
        //             }
        //         },
        //         function (error) {
        //             Xrm.Navigation.openAlertDialog({text: error.message});
        //         }
        //     );
        // }
        // else
        // {
        //     var reason = formContext.getAttribute(reasonField).getValue();
        //     if(reason == 171100000) // Initial
        //     {
        //         formContext.getControl(reasonField).setDisabled(true);
        //     }
        // }
    }
    else 
    {
        formContext.getAttribute(accountField).setValue(null);
    }
}

function checkDuplicateInitialRecord(executionContext) {
    var formContext = executionContext.getFormContext();
    var screeningCase = formContext.getAttribute(financialInquiryField).getValue();
    var reason = formContext.getAttribute(reasonField).getValue();
                
    var errId = "duplicateInitialRecord";
    formContext.getControl(reasonField).clearNotification(errId);

    if(screeningCase != null && reason == 171100000) // Initial
    {
        Xrm.WebApi.retrieveMultipleRecords("cra_financial_inquiry", "?$select=activityid&$filter=(cra_reason eq 171100000 and _regardingobjectid_value eq " + getId(screeningCase[0].id) + ")&$top=10").then(
            function success(result) {
                var id = getId(formContext.data.entity.getId());
                var duplicate = false;

                for (var i = 0; i < result.entities.length; i++) {
                    if(result.entities[i].activityid != id)
                    {
                        duplicate = true;
                        break;
                    }
                }   

                if(duplicate) 
                {
                    formContext.getControl(reasonField).setNotification("The Initial record aleady exists.", errId);
                }
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
}

