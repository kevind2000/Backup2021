var currentDateField = "cra_current_date";

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    formContext.getAttribute(currentDateField).setValue(new Date());
}
