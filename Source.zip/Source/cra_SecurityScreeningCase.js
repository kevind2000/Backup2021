// Web Resource: Security Screening Case Form Script

var previousSecurityScreening = "cra_previous_security_screening";
var canadianCitizen = "cra_citizenship_canadian";
var multipleCitizenship = "cra_citizenship_multiple";
var naturalizedCanadian = "cra_citizenship_naturalized_canadian";
var cerficateNumber = "cra_certificate_number";
var issueDate = "cra_date_of_issue";
var appliedCitizenship = "cra_citizenship_applied_for_canadian";
var citizenshipStatus = "cra_citizenship_status";
var temporaryStatus = "cra_temporary_status";
var temporaryStatusOther = "cra_temporary_status_other";
var expiryDate = "cra_citizenship_status_expiry_date";
var anticpatedStartDate = "cra_anticipated_start_date";
var anticpatedEndDate = "cra_anticipated_end_date";
var currentDateField = "cra_current_date";
var criminalRecord = "cra_declaredcriminalrecord";
var otherLegalName="cra_otherlegalnames";
var educationalCredentials = "cra_educational_credentials";
var professionalDesignations = "cra_professional_designations";
var clientCertification = "cra_client_certified_information";
var clientCertificationDate = "cra_client_certified_information_date";
var accountField = "cra_account";
var profileField = "cra_security_profile";

var globalFormContext = null;
var checkCitizenship = false;

function onLoad(executionContext) {
    var formContext = executionContext.getFormContext();
    globalFormContext = formContext;
    formContext.getAttribute(currentDateField).setValue(new Date());
    displayTabs(executionContext);
    addSubgridEventListener(formContext, "gridPreviousSecurityScreening", gridPreviousSecurityScreeningOnLoad);
    onPreviousScreeningChange(executionContext);
    displayCitizenship(executionContext);
    onEducationalCredentialsChange(executionContext);
    addSubgridEventListener(formContext, "gridEducationalCredentials", gridEducationalCredentialsOnLoad);
    onProfessionalDesignationsChange(executionContext);
    addSubgridEventListener(formContext, "gridProfessionalDesignations", gridProfessionalDesignationsOnLoad);
    addSubgridEventListener(formContext, "gridCitizenships", function() {checkCitizenship = true;});
    onOtherLegalNameChange(executionContext);
    addSubgridEventListener(formContext, "legalNamesGrid", gridOtherLegalNamesOnLoad);
    onCriminalRecordChange(executionContext);
    addSubgridEventListener(formContext, "criminalRecordsGrid", gridCriminalRecordOnLoad);
    addSubgridEventListener(formContext, "gridConsents", displayFinancialInquiry);
    displayFinancialInquiry();
    addSubgridEventListener(formContext, "gridConsents", displayLawEnforcementInquiry);
    displayLawEnforcementInquiry();
    formContext.data.process.addOnStageChange(onBPFStageChange);
}

function onBPFStageChange(executionContext)
{
    var formContext = executionContext.getFormContext();

    var currentStageId = formContext.data.process.getActiveStage().getId();
    if(currentStageId == "477d2ae4-4b34-48db-b4f5-2ae3cc59c9ca") //Intake
    {
        formContext.ui.tabs.get("tabActivity").setVisible(false);
    }
    else
    {
        formContext.ui.tabs.get("tabActivity").setVisible(true);
    }
}

function displayFinancialInquiry() {
    if(globalFormContext != null)
    {
        var enableFinancialInquiry = false;
        globalFormContext.ui.tabs.get("tabActivity").sections.get("secFinancialInquiry").setVisible(enableFinancialInquiry);

        var certification = globalFormContext.getAttribute(clientCertification).getValue();
        if(certification == 171100000)
        {
            var id = getId(globalFormContext.data.entity.getId());
            if(id == null || id == "") return;

            var today = new Date();
            today.setHours(0, 0, 0, 0);
            var dateValue = globalFormContext.getAttribute(clientCertificationDate).getValue();
            if(dateValue == null || dateValue > today)
            {
                return; 
            }
            
            Xrm.WebApi.retrieveMultipleRecords("cra_consent", "?$select=cra_consentid&$filter=(_cra_security_screening_case_value eq " + id + " and cra_verification eq 171100003 and cra_consent_given_status eq 171100001 and statecode eq 0)&$top=1").then(
                function success(result) {
                    enableFinancialInquiry = result.entities.length == 1;
                    globalFormContext.ui.tabs.get("tabActivity").sections.get("secFinancialInquiry").setVisible(enableFinancialInquiry);
                },
                function (error) {
                    Xrm.Navigation.openAlertDialog({text: error.message});
                }
            );
        }

        //grid = globalFormContext.getControl("gridFinancialInquiries");
        //grid.setDisabled(disableFinancialInquiry);
    }
}

function displayLawEnforcementInquiry() {
    if(globalFormContext != null)
    {
        var enableLawEnforcement = false;
        globalFormContext.ui.tabs.get("tabActivity").sections.get("secLawEnforcement").setVisible(enableLawEnforcement);

        var certification = globalFormContext.getAttribute(clientCertification).getValue();
        if(certification == 171100000)
        {
            var id = getId(globalFormContext.data.entity.getId());
            if(id == null || id == "") return;

            var today = new Date();
            today.setHours(0, 0, 0, 0);
            var dateValue = globalFormContext.getAttribute(clientCertificationDate).getValue();
            if(dateValue == null || dateValue > today)
            {
                return; 
            }
            
            //Verification of identity and background
            Xrm.WebApi.retrieveMultipleRecords("cra_consent", "?$select=cra_consentid&$filter=(_cra_security_screening_case_value eq " + id + " and cra_verification eq 171100000 and cra_consent_given_status eq 171100001 and statecode eq 0)&$top=1").then(
                function success(result) {
                    if(result.entities.length == 1)
                    {
                        //Law enforcement inquiry (criminal record check)
                        Xrm.WebApi.retrieveMultipleRecords("cra_consent", "?$select=cra_consentid&$filter=(_cra_security_screening_case_value eq " + id + " and cra_verification eq 171100004 and cra_consent_given_status eq 171100001 and statecode eq 0)&$top=1").then(
                            function success(result) {
                                enableLawEnforcement = result.entities.length == 1;
                                globalFormContext.ui.tabs.get("tabActivity").sections.get("secLawEnforcement").setVisible(enableLawEnforcement);
                            },
                            function (error) {
                                Xrm.Navigation.openAlertDialog({text: error.message});
                            }
                        );
                    }
                },
                function (error) {
                    Xrm.Navigation.openAlertDialog({text: error.message});
                }
            );
        }
    }
}

function gridPreviousSecurityScreeningOnLoad() {
    gridOnLoad(previousSecurityScreening, "gridPreviousSecurityScreening");
}

function gridEducationalCredentialsOnLoad() {
    gridOnLoad(educationalCredentials, "gridEducationalCredentials");
}
function gridProfessionalDesignationsOnLoad() {
    gridOnLoad(professionalDesignations, "gridProfessionalDesignations");
}
function gridOtherLegalNamesOnLoad() {
    gridOnLoad(otherLegalName, "legalNamesGrid");
}
function gridCriminalRecordOnLoad() {
    gridOnLoad(criminalRecord, "criminalRecordsGrid");
}

function gridOnLoad(ctlFieldName, gridName) {
    if(globalFormContext != null)
    {
        grid = globalFormContext.getControl(gridName);
        gridCount = grid.getGrid().getTotalRecordCount();

        ctlField = globalFormContext.getControl(ctlFieldName);
        if(gridCount > 0)
        {
            ctlField.setDisabled(true);
        }
        else
        {
            ctlField.setDisabled(false);
        }
    }
}

function onPreviousScreeningChange(executionContext) {
    onGridControlChange(executionContext, previousSecurityScreening, "gridPreviousSecurityScreening");
}

function onCriminalRecordChange(executionContext) {
    onGridControlChange(executionContext, criminalRecord, "criminalRecordsGrid");
}
function onOtherLegalNameChange(executionContext) {
    onGridControlChange(executionContext, otherLegalName, "legalNamesGrid");
}

function onEducationalCredentialsChange(executionContext) {
    onGridControlChange(executionContext, educationalCredentials, "gridEducationalCredentials");
}
function onProfessionalDesignationsChange(executionContext) {
    onGridControlChange(executionContext, professionalDesignations, "gridProfessionalDesignations");
}

function onGridControlChange(executionContext, ctlFieldName, gridName) {
    var formContext = executionContext.getFormContext();
    var grid = formContext.getControl(gridName);
    grid.setVisible(false);
    
    var formContext = executionContext.getFormContext();
    var ctlField = formContext.getAttribute(ctlFieldName).getValue();
    if(ctlField == 171100000) // Yes
    {
        grid.setVisible(true);
    }
}

function displayCitizenship(executionContext) {
    var formContext = executionContext.getFormContext();
    var id = formContext.data.entity.getId();
    // if(id == "")
    // {
    //     formContext.ui.tabs.get("tabCitizenship").setVisible(false);
    //     formContext.getAttribute(canadianCitizen).setRequiredLevel("none");
    //     formContext.getAttribute(multipleCitizenship).setRequiredLevel("none");
    // }
    // else
    {
        //formContext.ui.tabs.get("tabCitizenship").setVisible(true);
        //formContext.getAttribute(canadianCitizen).setRequiredLevel("required");
        //formContext.getAttribute(multipleCitizenship).setRequiredLevel("required");
        displayCitizenshipHeld(formContext);
        onNaturalizedCanadianChange(executionContext);
        onCriminalRecordChange(executionContext);
        onOtherLegalNameChange(executionContext);
    }
}

function displayTabs(executionContext) {
    var formContext = executionContext.getFormContext();
    var id = formContext.data.entity.getId();
    if(id == "")
    {
        formContext.ui.tabs.get("tabAdministrative").setVisible(false);
        formContext.ui.tabs.get("tabCitizenship").setVisible(false);
        formContext.ui.tabs.get("tabConsent").setVisible(false);
        formContext.ui.tabs.get("tabResidence").setVisible(false);
        formContext.ui.tabs.get("tabEmployment").setVisible(false);
        formContext.ui.tabs.get("tabEducationalCredential").setVisible(false);
        formContext.ui.tabs.get("tabActivity").setVisible(false);
        formContext.ui.tabs.get("tabReference").setVisible(false);
        formContext.ui.tabs.get("tabLegalName").setVisible(false);
        formContext.ui.tabs.get("tabCriminalRecord").setVisible(false);
        formContext.ui.tabs.get("tabSLA").setVisible(false);       
    }
    else
    {
        formContext.ui.tabs.get("tabAdministrative").setVisible(true);
        formContext.ui.tabs.get("tabCitizenship").setVisible(true);
        formContext.ui.tabs.get("tabConsent").setVisible(true);
        formContext.ui.tabs.get("tabResidence").setVisible(true);
        formContext.ui.tabs.get("tabEmployment").setVisible(true);
        formContext.ui.tabs.get("tabEducationalCredential").setVisible(true);

        formContext.ui.tabs.get("tabReference").setVisible(true);
        formContext.ui.tabs.get("tabLegalName").setVisible(true);
        formContext.ui.tabs.get("tabCriminalRecord").setVisible(true);
        formContext.ui.tabs.get("tabSLA").setVisible(true);

        var currentStageId = formContext.data.process.getActiveStage().getId();
        if(currentStageId == "477d2ae4-4b34-48db-b4f5-2ae3cc59c9ca") //Intake
        {
            formContext.ui.tabs.get("tabActivity").setVisible(false);
        }
        else
        {
            formContext.ui.tabs.get("tabActivity").setVisible(true);
        }
    }
}

function onCanadianCitizenChange(executionContext) {
    var formContext = executionContext.getFormContext();
    displayCitizenshipHeld(formContext);
    checkCitizenship = true;
}

function onMultipleCitizenshipChange(executionContext) {
    var formContext = executionContext.getFormContext();
    displayCitizenshipHeld(formContext);
    checkCitizenship = true;
}

function displayCitizenshipHeld(formContext) {
    var gridCitizenship = formContext.getControl("gridCitizenships");
    gridCitizenship.setVisible(false);

    var canadian = formContext.getAttribute(canadianCitizen).getValue();
    if(canadian == 171100001 ) // No
    {
        gridCitizenship.setVisible(true);
    }

    var multiple = formContext.getAttribute(multipleCitizenship).getValue();
    if(multiple == 171100000 ) // Yes
    {
        gridCitizenship.setVisible(true);
    }
}

function onNaturalizedCanadianChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var naturalized = formContext.getAttribute(naturalizedCanadian).getValue();

    formContext.getControl(appliedCitizenship).setVisible(false);
    formContext.getAttribute(appliedCitizenship).setRequiredLevel("none");
    onAppliedCitizenshipChange(executionContext);
    formContext.getControl(cerficateNumber).setVisible(false);
    formContext.getAttribute(cerficateNumber).setRequiredLevel("none");
    formContext.getControl(issueDate).setVisible(false);
    formContext.getAttribute(issueDate).setRequiredLevel("none");

    if(naturalized == 171100000) // Yes
    {
        formContext.getControl(cerficateNumber).setVisible(true);
        formContext.getAttribute(cerficateNumber).setRequiredLevel("required");

        formContext.getControl(issueDate).setVisible(true);
        formContext.getAttribute(issueDate).setRequiredLevel("required");

        formContext.getControl(appliedCitizenship).setVisible(false);
        formContext.getAttribute(appliedCitizenship).setRequiredLevel("none");
        formContext.getAttribute(appliedCitizenship).setValue(null);
        onAppliedCitizenshipChange(executionContext);

        formContext.getControl(temporaryStatus).setVisible(false);
        formContext.getAttribute(temporaryStatus).setRequiredLevel("none");
        formContext.getAttribute(temporaryStatus).setValue(null);
        onTemporaryStatusChange(executionContext);
    }
    else if(naturalized == 171100001) // No
    {
        formContext.getControl(cerficateNumber).setVisible(false);
        formContext.getAttribute(cerficateNumber).setRequiredLevel("none");
        formContext.getAttribute(cerficateNumber).setValue("");

        formContext.getControl(issueDate).setVisible(false);
        formContext.getAttribute(issueDate).setRequiredLevel("none");
        formContext.getAttribute(issueDate).setValue(null);
        
        formContext.getControl(appliedCitizenship).setVisible(true);
        formContext.getAttribute(appliedCitizenship).setRequiredLevel("required");
    }
}

function onAppliedCitizenshipChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var applied = formContext.getAttribute(appliedCitizenship).getValue();

    formContext.getControl(citizenshipStatus).setVisible(false);
    formContext.getAttribute(citizenshipStatus).setRequiredLevel("none");
    formContext.getControl(temporaryStatus).setVisible(false);
    formContext.getAttribute(temporaryStatus).setRequiredLevel("none");

    if(applied == 171100000) // Yes
    {
        formContext.getControl(citizenshipStatus).setVisible(true);
        formContext.getAttribute(citizenshipStatus).setRequiredLevel("required");

        formContext.getControl(temporaryStatus).setVisible(false);
        formContext.getAttribute(temporaryStatus).setRequiredLevel("none");
        formContext.getAttribute(temporaryStatus).setValue(null);
        onTemporaryStatusChange(executionContext);
    }
    else if(applied == 171100001) // No
    {
        formContext.getControl(citizenshipStatus).setVisible(false);
        formContext.getAttribute(citizenshipStatus).setRequiredLevel("none");
        formContext.getAttribute(citizenshipStatus).setValue(null);
        onCitizenshipStatusChange(executionContext);

        formContext.getControl(temporaryStatus).setVisible(true);
        formContext.getAttribute(temporaryStatus).setRequiredLevel("required");
    }
}

function onCitizenshipStatusChange(executionContext) {
    var formContext = executionContext.getFormContext();
    displayExpiryDate(formContext);
}

function onTemporaryStatusChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var temporaries = formContext.getAttribute(temporaryStatus).getValue();
    if(temporaries != null && temporaries.includes(171100004)) // Other
    {
        formContext.getControl(temporaryStatusOther).setVisible(true);
        formContext.getAttribute(temporaryStatusOther).setRequiredLevel("required");
    }
    else 
    {
        formContext.getControl(temporaryStatusOther).setVisible(false);
        formContext.getAttribute(temporaryStatusOther).setRequiredLevel("none");
        formContext.getAttribute(temporaryStatusOther).setValue("");
    }

    displayExpiryDate(formContext);
}

function displayExpiryDate(formContext) {

    var expiryDateVisible = false;

    var citizenship = formContext.getAttribute(citizenshipStatus).getValue();
    if(citizenship == 171100003 || citizenship == 171100004 ) // Permanent resident or Refugee status
    {
        expiryDateVisible = true;
    }

    var temporaries = formContext.getAttribute(temporaryStatus).getValue();
    if(temporaries != null && temporaries.includes(171100000)) // Work permit
    {
        expiryDateVisible = true;
    }
    if(temporaries != null && temporaries.includes(171100001)) // Study permit
    {
        expiryDateVisible = true;
    }
    if(temporaries != null && temporaries.includes(171100003)) // Protected person status
    {
        expiryDateVisible = true;
    }

    if(expiryDateVisible)
    {
        formContext.getControl(expiryDate).setVisible(true);
        formContext.getAttribute(expiryDate).setRequiredLevel("required");
    }
    else 
    {
        formContext.getControl(expiryDate).setVisible(false);
        formContext.getAttribute(expiryDate).setRequiredLevel("none");
        formContext.getAttribute(expiryDate).setValue(null);
    }   
}

function onExpiryDateChange(executionContext) {
    checkPastDate(executionContext, expiryDate);  
}

function onAnticipatedStartDateChange(executionContext) {
    checkPastDate(executionContext, anticpatedStartDate);  
}

function onAnticipatedEndDateChange(executionContext) {
    checkPastDate(executionContext, anticpatedEndDate);  
}

function onAccountChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var acccount = formContext.getAttribute(accountField).getValue();

    if(acccount != null)
    {
        var accountId = getId(acccount[0].id);
        Xrm.WebApi.retrieveRecord("account", accountId, "?$select=_cra_security_profile_value").then(
            function success(result) {
                var profile = null;
                if(result._cra_security_profile_value != null)
                    profile = [{id:result._cra_security_profile_value, entityType: "cra_securityprofile", name: result["_cra_security_profile_value@OData.Community.Display.V1.FormattedValue"]}];
                formContext.getAttribute(profileField).setValue(profile);
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
    else 
    {
        formContext.getAttribute(profileField).setValue(null);
    }
}

function onProfileChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var profile = formContext.getAttribute(profileField).getValue();

    if(profile != null)
    {
        var profileId = getId(profile[0].id);
        Xrm.WebApi.retrieveRecord("cra_securityprofile", profileId, "?$select=_cra_account_value").then(
            function success(result) {
                var account = null;
                if(result._cra_account_value != null)
                    account = [{id:result._cra_account_value, entityType: "account", name: result["_cra_account_value@OData.Community.Display.V1.FormattedValue"]}];
                formContext.getAttribute(accountField).setValue(account);
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
    else 
    {
        formContext.getAttribute(accountField).setValue(null);
    }
}

function onSave(executionContext) {
    var formContext = executionContext.getFormContext();
    var id = formContext.data.entity.getId();
    if(id == "")
    {
       return;
    }

    var errId = "citizenshipRequired";
    var gridCitizenship = formContext.getControl("gridCitizenships");
    var requireCitizenship = gridCitizenship.getVisible();
    if(checkCitizenship && requireCitizenship)
    {
        var total = gridCitizenship.getGrid().getTotalRecordCount();
        if(total == 0)
        {
            formContext.ui.setFormNotification("Citizenship: Countries Required. ", "ERROR", errId);
            executionContext.getEventArgs().preventDefault();
        }
        else
        {
            formContext.ui.clearFormNotification(errId);
            checkCitizenship = false;
        }
    }
    else
    {
        formContext.ui.clearFormNotification(errId);
    }
}