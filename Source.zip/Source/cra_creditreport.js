// Web Resource: Credit Report Form Script

var financialInquiryField = "cra_financialinquiry";
var reasonField = "cra_reason";

function onLoad(executionContext) {
    onCaseChange(executionContext);
    checkDuplicateInitialRecord(executionContext);
}

function onCaseChange(executionContext) {
    var formContext = executionContext.getFormContext();
    var financialInquiry = formContext.getAttribute(financialInquiryField).getValue();

    if(financialInquiry != null)
    {
        var id = getId(formContext.data.entity.getId());
        if(id == "")
        {
            Xrm.WebApi.retrieveMultipleRecords("cra_creditreport", "?$select=cra_creditreportid&$filter=(_cra_financialinquiry_value eq " + getId(financialInquiry[0].id) + ")&$top=10").then(
                function success(result) {
                    if(result.entities.length == 0) 
                    {
                        formContext.getAttribute(reasonField).setValue(171100000); //Initial
                        formContext.getControl(reasonField).setDisabled(true);
                    }
                    else
                    {
                        formContext.getControl(reasonField).setDisabled(false);
                    }
                },
                function (error) {
                    Xrm.Navigation.openAlertDialog({text: error.message});
                }
            );
        }
        else
        {
            var reason = formContext.getAttribute(reasonField).getValue();
            if(reason == 171100000) // Initial
            {
                formContext.getControl(reasonField).setDisabled(true);
            }
        }
    }
}

function checkDuplicateInitialRecord(executionContext) {
    var formContext = executionContext.getFormContext();
    var financialInquiry = formContext.getAttribute(financialInquiryField).getValue();
    var reason = formContext.getAttribute(reasonField).getValue();
                
    var errId = "duplicateInitialRecord";
    formContext.getControl(reasonField).clearNotification(errId);

    if(financialInquiry != null && reason == 171100000) // Initial
    {
        Xrm.WebApi.retrieveMultipleRecords("cra_creditreport", "?$select=cra_creditreportid&$filter=(cra_reason eq 171100000 and _cra_financialinquiry_value eq " + getId(financialInquiry[0].id) + ")&$top=10").then(
            function success(result) {
                var id = getId(formContext.data.entity.getId());
                var duplicate = false;

                for (var i = 0; i < result.entities.length; i++) {
                    if(result.entities[i].cra_creditreportid != id)
                    {
                        duplicate = true;
                        break;
                    }
                }   

                if(duplicate) 
                {
                    formContext.getControl(reasonField).setNotification("The Initial record aleady exists.", errId);
                }
            },
            function (error) {
                Xrm.Navigation.openAlertDialog({text: error.message});
            }
        );
    }
}

