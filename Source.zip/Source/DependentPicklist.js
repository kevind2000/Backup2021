// Web Resource: Dependent Picklists
//
// Supports dependent cascading picklists so that the options presented in one list can be dependent on the options already selected
// in previous lists.

// Entity and Field Names for fetchXML statement
var picklistItemEntityName = "cra_picklistitem";
var picklistItemEntityIdField = "cra_picklistitemid";
var picklistEntityName = "cra_picklist";
var picklistEntityIdField = "cra_picklistid";
var picklistItemAssociationEntityName = "cra_picklistitemassociation";
var picklistItemAssociationEntityIdField = "cra_picklistitemassociationid";
var picklistitemAssociationPicklistField = "cra_picklistitem";
var picklistitemAssociationFromField = "cra_picklistitem";
var picklistitemAssociationToField = "cra_picklistitemid";
var picklistitemAssociationPickistFile = "cra_picklist";
var filteredbyPicklistItemAssociationField = "cra_filteredbypicklistitemassociation";
var picklistItemAssociationRuleEntityName = "cra_picklistitemassociationrule";
var picklistItemAssociationRuleEntityIdField = "cra_picklistitemassociationruleid";
var picklistitemAssociationRuleFromField = "cra_picklistitemassociation";
var picklistitemAssociationRuleToField = "cra_picklistitemassociationid";
var picklistitemAssociationLimitToOptionsetValuesField = "cra_limittooptionsetvalues";
var effectiveDateField = "cra_effectivedate";
var expiryDateField = "cra_expirydate";
var sortorderField = "cra_sortorder";
var codeField = "cra_code";
var nameField = "cra_name";
var statecodeField = "statecode";
var activestateCodeValue = "0";
var isdefaultValueYes = "0";
var emptyGuid = "{00000000-0000-0000-0000-000000000000}";  //Guid.Empty




// Function: cascadePicklist
//
// Description: Constructs a custom view for a dependent picklist field. The main part of this is the construction of the fetchXML statement which
//              filters the picklist items based on the picklist, effective and expiry dates, previous picklist selections, and
//              picklist item association rules.
//
// Parameters:
// formContext = form context
// picklistid = guid of picklist being filtered
// lookupCtrl = control object of picklist field on the form
// lookpDepsConfig = | delimited list of other picklistitem lookup fields that this field is dependent on.
// limitByOptionSetValue = Limit the results to PicklistItem Associations where the LimitByOptionSetValues contains the value
function cascadePicklist(formContext, picklistCode, lookupCtrl, lookupDepsConfig, limitByOptionSetValueOnRelatedEntity) {
    var limitByOptionsetValue = null;
    
    var id = formContext.data.entity.getId();

    // Lookup the Optionset value to Limit By if limitByOptionSetValueOnRelatedEntity not null
    if (limitByOptionSetValueOnRelatedEntity != null && limitByOptionSetValueOnRelatedEntity != "null") {
        limitByOptionsetValue = getOptionSetValueFromRelatedEntity(picklistitemAssociationLimitToOptionsetValuesField);
        var parts = limitByOptionSetValueOnRelatedEntity.split("|");
        if (parts.length == 1) {
            limitByOptionsetValue = formContext.getAttribute(parts[0]).getValue();
        }
        else if (parts.length == 4) {
            var attribute = formContext.getAttribute(parts[0]);
            if (attribute != null) {
                var relatedEntity = parts[1];
                var relatedEntityPrimaryKey = parts[2];
                var optionsetFieldName = parts[3];
                var value = attribute.getValue();
                if (value != null) {
                    var id = value[0].id.replace('{', '').replace('}', '');
                    var results = retrieveWebAPIData(relatedEntity, optionsetFieldName, relatedEntityPrimaryKey + " eq " + id);
                    if (results != null && results.value != null && results.value[0] != null) {
                        limitByOptionsetValue = results.value[0][optionsetFieldName];
                    }
                }
            }
        }
    }

    var lookupDeps = null;

    if (lookupDepsConfig != null && lookupDepsConfig != "null") {
        lookupDeps = lookupDepsConfig.split("|");
    }

    // Instead of using a custom viewID, the following blog post recommends using the view Id from the default view
    // http://www.powerxrm.com/lookup-filtering-using-addcustomview/
    
  

    var viewId = lookupCtrl.getDefaultView(); //"{00000000-0000-0000-0000-000000000001}";  // dummy guid
    
    
    var today = new Date();
    var todayDate = today.getFullYear() + "-" + (today.getMonth() + 1) + "-" + today.getDate();

    // start the fetchXml statement which will filter for the correct picklist items based on picklist code, dates, and status
    var fetchxml =
		'<fetch mapping="logical" output-format="xml-platform" version="1.0" distinct="true">' +
		'  <entity name="' + picklistItemEntityName + '">' +
		'    <attribute name="' + nameField + '" />' +
		'    <attribute name="' + picklistItemEntityIdField + '" />' +
		'    <filter type="and">' +
		'      <filter type="or">' +
		'        <condition value="' + todayDate + '" attribute="' + effectiveDateField + '" operator="on-or-before" />' +
		'        <condition attribute="' + effectiveDateField + '" operator="null" />' +
		'      </filter>' +
		'      <filter type="or">' +
		'        <condition value="' + todayDate + '" attribute="' + expiryDateField + '" operator="on-or-after" />' +
		'        <condition attribute="' + expiryDateField + '" operator="null" />' +
		'      </filter>' +
		'      <condition value="' + activestateCodeValue + '" attribute="' + statecodeField + '" operator="eq" />' +
		'    </filter>' +
		'    <link-entity name="' + picklistItemAssociationEntityName + '" from="' + picklistitemAssociationFromField + '" to="' + picklistitemAssociationToField + '">' +
		'      <order attribute="' + sortorderField + '" />' +
        '      <link-entity name="' + picklistEntityName + '" from="' + picklistEntityIdField + '" to="' + picklistitemAssociationPickistFile + '" >' +
        '        <filter>' +
        '          <condition attribute="' + codeField + '" operator="eq" value="' + picklistCode + '" />' +
        '        </filter>' +
        '      </link-entity>' +
        '      <filter type="and">' +
		'	     <filter type="or">' +
		'          <condition value="' + todayDate + '" attribute="' + effectiveDateField + '" operator="on-or-before" />' +
		'          <condition attribute="' + effectiveDateField + '" operator="null" />' +
		'        </filter>' +
		'        <filter type="or">' +
		'          <condition value="' + todayDate + '" attribute="' + expiryDateField + '" operator="on-or-after" />' +
		'          <condition attribute="' + expiryDateField + '" operator="null" />' +
		'        </filter>' +
		'        <condition value="' + activestateCodeValue + '" attribute="' + statecodeField + '" operator="eq" />';
    if (limitByOptionsetValue != null) {
        //Add the Contains criteria
        fetchxml += '       <filter type="or"><condition value="%' + limitByOptionsetValue + '%" attribute="' + picklistitemAssociationLimitToOptionsetValuesField + '" operator="like" /><condition attribute="' + picklistitemAssociationLimitToOptionsetValuesField + '" operator="null" /></filter>';
    }
    //close the Filter
    fetchxml += '      </filter>';

    // Add in the dependent lookups. For first picklist in the chain there will be none,
    // so the above fetchxml is complete (with the closing statements added later).
    // These items will be inner joined so a rule must be found that matches all of the picklist values.
    if (lookupDeps != null) {
    
        for (i = 0; i < lookupDeps.length; i++) {
            var depField = formContext.getAttribute(lookupDeps[i]);
			
			// link to the picklist rules that are for this picklist item
			fetchxml += '      <link-entity name="' + picklistItemAssociationRuleEntityName + '" from="' + picklistitemAssociationRuleFromField + '" to="' + picklistitemAssociationRuleToField + '" link-type="inner" >' +
						'        <link-entity name="' + picklistItemAssociationEntityName + '" from="' + picklistItemAssociationEntityIdField + '" to="' + filteredbyPicklistItemAssociationField + '" link-type="inner" > ' +
						'          <filter type="and">';
			
            if (depField != null) {
                if (depField.getValue() != null) {
                    var dependentValueId = depField.getValue()[0].id.replace('{', '').replace('}', '');
                    fetchxml += '            <condition attribute="' + picklistitemAssociationPicklistField + '" operator="eq" value="' + dependentValueId + '" />'
                }
                else {
                    //No value selected, return nothing
                    fetchxml += '            <condition attribute="' + picklistitemAssociationPicklistField + '" operator="eq" value="' + emptyGuid + '" />'
                }
            }
            else {
                //No value selected, return nothing
                fetchxml += '            <condition attribute="' + picklistitemAssociationPicklistField + '" operator="eq" value="' + emptyGuid + '" />'
            }
			
			fetchxml += '          </filter>' +
                    '        </link-entity>' +
                    '      </link-entity>';
        }
        
    }

    // Close the PicklistItemAssociation Link

    fetchxml += '    </link-entity>' +
    '  </entity>' +
	'</fetch>';

    // create the view layout which just contains the lookups to the picklist items
    var layoutXml =
		'<grid name="resultset" object="1" jump="' + nameField + '" select="1" preview="1" icon="1">' +
		'	<row name="result" id="' + picklistItemEntityIdField + '">' +
		'		<cell name="' + nameField + '" width="150" />' +
		'	</row>' +
		'</grid>';
    //console.log('Filtering ' + lookupCtrl.getName() + ' control to display ' + picklistCode + ' picklist filtered by ' + limitByOptionSetValueOnRelatedEntity);
    //console.log('Fetch XML: ' + fetchxml);
    // add the custom view to the lookup control
    lookupCtrl.addCustomView(viewId, picklistItemEntityName, "Filtered List", fetchxml, layoutXml, true);
    
    
    
}

//
// Description: This method uses the addPreSearch method for lookup fields to bind a function that will create a custom view for the lookup field when a search happens.
//				This method needs to be invoked during the form load for each dependent picklist on the form.
//
// Parameters:
// executionContext = execution context sent by form
// picklistCode = value for code of picklist being filtered
// lookupFieldName = schema name of field being filtered
// lookupDependentFieldsConfig = comma delimited list of other picklistitem lookup fields that this field is dependent on. Will be null for first list in chain or
//                   picklists which do not have any dependencies.
// limitByOptionSetValueOnRelatedEntity = Limit the results to PicklistItem Associations where the LimitByOptionSetValues contains the value of the optionset on the related entity. if Null then no limit.
//                   | delimited parameter= LookupFieldLogicalNameOnCurrentEntity|LookupEntityRestName|LookupEntityPrimaryKeyFieldLogicalName|OptionsetFieldLogicalNameOnRelatedEntity
//
// EG: cra_accountid|accounts|accountid|cra_accounttype : gets the cra_accounttype selected value from the account where the accountid = is in the cra_accountid attribute on the current form.
// EG: cra_correspondence|cra_correspondences|cra_correspondenceid|cra_intakeprogram : gets the cra_intakeprogram selected value from the cra_correspondence where cra_correspondence = is in the attribute cra_correspondence on the current form.                    
// EG: cra_correspondence|incidents|incidentid|cra_intakeprogram : gets the cra_intakeprogram selected value from the cra_correspondence where cra_correspondence = is in the attribute cra_correspondence on the current form.                    
// if the parameters has no |, it is assumed the optionsetvalue is on the currententity.
function addPreSearchFilter(executionContext, picklistCode, lookupFieldName, lookupDependentFieldsConfig, limitByOptionSetValueOnRelatedEntity) {
    var formContext = executionContext.getFormContext();
    var lookupCtrl = formContext.getControl(lookupFieldName);
    // add the pre-search method to the lookup control
    if (lookupCtrl != null) {
        // remove any existing filter
//        try {
//            console.log('Removing filtering on ' + lookupFieldName);
//            lookupCtrl.removePreSearch(function () { cascadePicklist(formContext, picklistCode, lookupCtrl, lookupDependentFieldsConfig, limitByOptionSetValueOnRelatedEntity) });
//        }
//        catch(e) {
//            console.log(e);
//        }
        
        // add the filter
//        console.log('Adding a filter on ' + lookupFieldName);
        lookupCtrl.addPreSearch(function () { cascadePicklist(formContext, picklistCode, lookupCtrl, lookupDependentFieldsConfig, limitByOptionSetValueOnRelatedEntity) });
    }
}

// Description: register this method on a Field that when the value changes you need to clear a collection of child dependent fields.
//Parameters: 
// executionContext = execution context sent by form
// fieldsToClear = comma delimited list of fields to clear.
function clearDependentFieldsOnChange(executionContext, fieldsToClear) {
    var formContext = executionContext.getFormContext();
    if (fieldsToClear != null) {
        var fields = fieldsToClear.split(",");
        for (i = 0; i < fields.length; i++) {
            var fieldToclear = formContext.getAttribute(fields[i]);
            if (fieldToclear != null) {
                formContext.getAttribute(fields[i]).setValue(null);
            }
        }
    }
}

function getOptionSetValueFromRelatedEntity(formContext, limitByOptionSetValueOnRelatedEntity) {
    // Lookup the Optionset value to Limit By if limitByOptionSetValueOnRelatedEntity not null
    var limitByOptionsetValue = null;
    if (limitByOptionSetValueOnRelatedEntity != null && limitByOptionSetValueOnRelatedEntity != "null") {
        var parts = limitByOptionSetValueOnRelatedEntity.split("|");
        if (parts.length == 1) {
            limitByOptionsetValue = formContext.getAttribute(parts[0]).getValue();
        }
        else if (parts.length == 4) {
            var attribute = formContext.getAttribute(parts[0]);
            if (attribute != null) {
                var relatedEntity = parts[1];
                var relatedEntityPrimaryKey = parts[2];
                var optionsetFieldName = parts[3];
                var value = attribute.getValue();
                if (value != null) {
                    var id = value[0].id.replace('{', '').replace('}', '');
                    var results = retrieveWebAPIData(relatedEntity, optionsetFieldName, relatedEntityPrimaryKey + " eq " + id);
                    if (results != null && results.value != null && results.value[0] != null) {
                        limitByOptionsetValue = results.value[0][optionsetFieldName];
                    }
                }
            }
        }
    }
            

return limitByOptionsetValue;
    
}

function setDefaultValueOrClear(executionContext, fieldToSet, fieldToSetPicklistCode, fieldThatChanged, limitByOptionSetValueOnRelatedEntity) {
    //console.log('setDefaultValueOrClear - set ' + fieldToSet + ' field becuase ' + fieldThatChanged + 'changed');
    var formContext = executionContext.getFormContext();
    //var formContext = executionContext;
    
    var fieldThatChangedCtrl = formContext.getControl(fieldThatChanged);
    var fieldToSetCtrl = formContext.getControl(fieldToSet);
    var optionSetValue = getOptionSetValueFromRelatedEntity(formContext, limitByOptionSetValueOnRelatedEntity)
    if (fieldThatChangedCtrl != null && fieldToSetCtrl != null) {

         //Clear the field
         formContext.getAttribute(fieldToSet).setValue(null);

        //get the value
        var selectedFieldThatChangedValue = formContext.getAttribute(fieldThatChanged).getValue();
        if (selectedFieldThatChangedValue != null) {
            //See if there is a default
            var selectedFieldPicklistItemId = selectedFieldThatChangedValue[0].id.replace('{', '').replace('}', '');

            var fetchXML = ["<fetch top='1'><entity name='cra_picklistitemassociation'><attribute name='cra_picklistitem' /><order attribute='" + picklistitemAssociationLimitToOptionsetValuesField + "' descending='true'/>" +
                            "<filter type='and'><condition attribute='cra_isdefaultvalue' operator='eq' value='1' /><filter type='or'><condition attribute='" + picklistitemAssociationLimitToOptionsetValuesField + "' operator='like' value='%" + optionSetValue + "%' /><condition attribute='cra_limittooptionsetvalues' operator='null'/></filter></filter>" +
                            "<link-entity name='cra_picklistitemassociationrule' from='cra_picklistitemassociation' to='cra_picklistitemassociationid' link-type='inner' alias='PIAR'>" +
                            " <link-entity name='cra_picklistitemassociation' from='cra_picklistitemassociationid' to='cra_filteredbypicklistitemassociation' link-type='inner' alias='FPIA'>" +
                            "  <filter><condition attribute='cra_picklistitem' operator='eq' value='" + selectedFieldPicklistItemId + "' /></filter>" +
                            " </link-entity>" +
                            "</link-entity>" +
                            "<link-entity name='cra_picklist' from='cra_picklistid' to='cra_picklist' alias='PL'>" +
                            " <filter><condition attribute='cra_code' operator='eq' value='" + fieldToSetPicklistCode + "' /></filter>" +
                            "</link-entity></entity></fetch>"].join('');

            var results = retrieveWebAPIDataFetchXmlWithAnnotations("cra_picklistitemassociations", fetchXML);

            if (results != null && results.value != null && results.value[0] != null) {

                var defaultValue = results.value[0]["_cra_picklistitem_value"];
                if (defaultValue != null) {
                    var defaultValueReference = new Array();
                    defaultValueReference[0] = new Object();
                    defaultValueReference[0].id = defaultValue;
                    var defaultValueName = results.value[0]["_cra_picklistitem_value@OData.Community.Display.V1.FormattedValue"].split("|");
                    //if (Xrm.Page.context.getUserLcid() == "1033") {		
					if (Xrm.Utility.getGlobalContext().userSettings.languageId == "1033") {
                       defaultValueReference[0].name = defaultValueName[0];
                    }
                    else {
                        defaultValueReference[0].name = defaultValueName[1];
                    }
                    defaultValueReference[0].entityType = "cra_picklistitem";
                    formContext.getAttribute(fieldToSet).setValue(defaultValueReference);
                    formContext.getAttribute(fieldToSet).fireOnChange();
                }
            }
        }

    }
}

function setDefaultView(executionContext, controlName, viewId) {


    var formContext = executionContext.getFormContext();
    var control = formContext.getControl(controlName);
    if (controlName=="header_process_cra_intakeprogram")
   {
        $("#header_process_cra_intakeprogram").attr("disableViewPicker", "0");
         var customViewId = "{F47915A0-A48E-E911-80F4-005056813013}"; // new id
         control.setDefaultView(customViewId);
         
        $("#header_process_cra_intakeprogram").attr("disableViewPicker", "1");
   }
    
    else{
  
        if (control != null) {
            control.setDefaultView("{" + viewId + "}");
        }
    }
}